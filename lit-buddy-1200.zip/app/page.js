
export default function Home() {
  return <p>Welcome to Lit Buddy — choose a feature.</p>;
}
